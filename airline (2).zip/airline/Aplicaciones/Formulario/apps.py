from django.apps import AppConfig


class FormularioConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Aplicaciones.Formulario'
