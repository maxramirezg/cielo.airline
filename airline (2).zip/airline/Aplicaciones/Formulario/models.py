from django.db import models 



"""
high level support for doing this and that.
"""    
class usuarios(models.Model):
    


    id_usuario=models.PositiveIntegerField()
    rut_usuario=models.PositiveSmallIntegerField()   
    nombre_usuario=models.CharField(max_length=30)
    
    
    
class paises(models.Model):
    
    """
high level support for doing this and that.
"""
    
    nombre_pais=models.CharField(max_length=30)
    monto_pais=models.PositiveIntegerField()
    nombre_empresa=models.CharField(max_length=30)
    
    
    
class  vuelo(models.Model):
    
    """
high level support for doing this and that.
"""
    id_vuelo=models.PositiveIntegerField()
    nombre_empresa=models.CharField(max_length=30)
    fecha_vuelo=models.PositiveIntegerField()
    id_usuario=models.PositiveIntegerField()
    rut_usuario=models.PositiveSmallIntegerField()
    nombre_usuario=models.CharField(max_length=30)
    apellido_usuario=models.CharField
    correo_usuario=models.CharField(max_length=50)
    monto_pais=models.PositiveIntegerField()
    asiento_asignado=models.PositiveSmallIntegerField()
